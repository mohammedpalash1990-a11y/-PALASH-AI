# PALASH AI — GitHub Connection & Repository Push Integration

Connect PALASH AI directly to `mohammedpalash1990-a11y/-PALASH-AI` with authenticated GitHub access, live repository synchronization, automated pull request creation, and Owner-approved push of completed workspace changes.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Target Repository & Push Behavior Confirmed**: You specified `mohammedpalash1990-a11y/-PALASH-AI` (`gh repo clone mohammedpalash1990-a11y/-PALASH-AI`) and requested pushing completed code changes directly to this repository.
>
> Because unauthenticated GitHub requests are rate-limited and cannot push code, one credential configuration step will be needed once built:
> - **Option A (Recommended — Fastest)**: Connect a GitHub Personal Access Token (`repo` scope) via AI Studio Secrets (`GITHUB_TOKEN`) or the in-console Owner GitHub Connection dialog (held strictly in server-side memory for the active session).
> - **Option B (Browser OAuth)**: Configure `GITHUB_CLIENT_ID` and `GITHUB_CLIENT_SECRET` in Secrets using the exact preview callback URLs so you can authorize via a GitHub OAuth popup.

- **Confirmed Target Repository**: `mohammedpalash1990-a11y/-PALASH-AI` (primary platform repository, default branch `main`).
- **Confirmed Push Workflow**: Support both creating a feature branch + Pull Request and pushing directly to a selected target branch after explicit Owner confirmation in the Approval Gate.
- **Safety Default**: High-risk branch writes to `main` always pass through the Owner Approval Gate before executing the remote push.

---

### 1. Overview & Core Concept

- **What It Does**: Turns the **GitHub Engineering** console into a live two-way engineering bridge for `mohammedpalash1990-a11y/-PALASH-AI`. Owners can authenticate with GitHub, inspect real commits/branches/trees without hitting anonymous rate limits, pull or compare workspace files against the remote repository, stage file diffs, create Pull Requests, and push completed PALASH AI updates directly to GitHub.
- **Target Audience / Persona**: The PALASH AI Owner (`mohammedpalash1990@gmail.com`) managing the core platform codebase and connected business repositories from desktop or mobile.
- **Key Value**: Eliminates manual file copying or external CLI setup by letting you inspect, review, approve, and push workspace code directly from the command center—with full audit logging and rollback protection.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Connection Status & Auth Setup**: Opening **GitHub Engineering** displays a clean connection bar showing whether GitHub is authenticated (via `GITHUB_TOKEN`, GitHub OAuth popup, or unauthenticated public mode) alongside the connected repository (`mohammedpalash1990-a11y/-PALASH-AI`). If unauthenticated, an inline setup panel lets the Owner launch GitHub OAuth or enter a session PAT, plus copy the exact one-line local `gh` / `git` setup command if preferred.
  2. **Repository Sync & Diff Preview**: Clicking **Sync & Compare** checks the remote repository's latest `HEAD` commit against the current workspace files and displays a compact, scannable table of changed, added, or identical modules with byte counts and status labels.
  3. **Branch, Commit & Push Workflow**: The Owner enters a commit message, picks a target branch (e.g., `feat/palash-ai-updates` or `main`), and chooses either **Push to Branch & Open PR** or **Queue Direct Push to `main`**.
  4. **Approval Gate & Live Push Execution**: Direct pushes to protected branches (`main`) queue an entry in **Approvals & Safety** with the exact file list and commit preview. Once approved (or immediately for an authorized feature branch push), a live progress tracker shows staging, tree creation, commit signing, and remote push confirmation with a clickable link to the live GitHub commit or Pull Request.

- **Visual Identity & Theme**:
  - **Aesthetic Direction**: Clean, utilitarian enterprise developer console aligned with the existing PALASH AI workspace—high clarity, crisp 1px borders, and zero ornamental clutter.
  - **Color Palette & Mood**: 60% neutral slate canvas (`#F8FAFC` light / `#020617` dark), 30% structured card surfaces (`#FFFFFF` / `#0F172A` with `1px` `slate-200` / `slate-800` borders), and 10% teal (`#0D9488`) primary action accents, paired with semantic green (`#16A34A`), amber (`#D97706`), and crimson (`#DC2626`) state text.
  - **Typography & Hierarchy**: `Plus Jakarta Sans` section headers, `DM Sans` body and control labels, and `JetBrains Mono` with `tabular-nums` for commit SHAs, file sizes, branch names, and file counts.
  - **Component Styling & Layout**: Single-elevation panels with generous outer padding, compact `40px` table rows for changed files, clean inline typographic metadata separated by `·` (zero pill capsules on static tags), and responsive multi-column grids for desktop (`1440px`) and mobile.
- **Interactive Feedback & Motion**: Immediate inline loading spinners and stage indicators during API sync and push calls (`≤200ms` button feedback), explicit empty states when no diff exists, actionable error banners on token scope or branch protection failures, and automatic audit log updates upon completion.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: GitHub REST Git Data API + Optional Local Git Remote Sync**
  - *Chosen Approach*: Implement primary push and PR creation through the server-side GitHub REST API (creating blobs, trees, commits, branch refs, and PRs over HTTPS), complemented by initializing the local workspace `git` remote (`mohammedpalash1990-a11y/-PALASH-AI`) for diff computation and local git readiness.
  - *Why*: Works reliably inside containerized cloud runtimes without requiring `gh` CLI installation or storing plaintext credentials in `.git/config`, while producing real commits and Pull Requests on GitHub.
  - *Alternatives Considered*: Running raw `git push` shell commands exclusively; rejected as sole mechanism because credential prompting and interactive SSH fail inside headless web containers.

- **Decision 2: Dual Authentication Support (Server Secret / Session PAT + GitHub OAuth Popup)**
  - *Chosen Approach*: Support `GITHUB_TOKEN` from environment Secrets as highest priority, plus an Owner-only in-memory session token connector and a popup-based GitHub OAuth flow (`GITHUB_CLIENT_ID` / `GITHUB_CLIENT_SECRET`) compliant with preview iframe `postMessage` rules.
  - *Why*: Unblocks immediate push testing via a PAT in seconds while also offering seamless one-click OAuth for long-term usage.

- **Decision 3: Mandatory Owner Approval Before Pushing to `main`**
  - *Chosen Approach*: Feature branch pushes can run directly on Owner request, whereas direct pushes or merges targeting `main` create an approval gate record that executes the real GitHub push when approved.
  - *Why*: Satisfies PALASH AI's core rule that no high-risk production repository change occurs without explicit human approval.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                         PALASH AI Web Client                              │
│                                                                           │
│  ┌──────────────────────┐   ┌────────────────────┐   ┌─────────────────┐  │
│  │ GitHub Engineering   │   │ OAuth Popup Flow   │   │ Approvals &     │  │
│  │ Console              │──▶│ (postMessage sync) │   │ Safety View     │  │
│  │ • Connection status  │   └────────────────────┘   │ • Approve push  │  │
│  │ • Workspace vs Repo  │                            │ • Reject push   │  │
│  │   diff table         │◀───────────────────────────┴─────────────────┘  │
│  │ • Commit & Push form │                                                 │
│  └──────────┬───────────┘                                                 │
└─────────────┼─────────────────────────────────────────────────────────────┘
              │ Authenticated Bearer API calls
              ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                      PALASH AI Backend Server                             │
│                                                                           │
│  ┌──────────────────────────────────┐   ┌──────────────────────────────┐  │
│  │ GitHub Auth & Session Resolver   │   │ Workspace Snapshot & Diff    │  │
│  │ • Server env GITHUB_TOKEN        │   │ Scanner                      │  │
│  │ • OAuth code exchange            │   │ • Reads safe project files   │  │
│  │ • In-memory Owner session PAT    │   │ • Excludes .env / .data /    │  │
│  └──────────────────┬───────────────┘   │   node_modules / dist        │  │
│                     │                   └──────────────┬───────────────┘  │
│                     ▼                                  ▼                  │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │ GitHub Engineering & Push Engine                                    │  │
│  │ • Inspect repo, branches, commits, file trees                       │  │
│  │ • Stage blobs -> create tree -> create commit -> update ref / PR    │  │
│  │ • Triggered directly (feature branch) or via Approval Gate (main)   │  │
│  └──────────────────────────────────┬──────────────────────────────────┘  │
└─────────────────────────────────────┼─────────────────────────────────────┘
                                      │ HTTPS (api.github.com allowlist)
                                      ▼
┌───────────────────────────────────────────────────────────────────────────┐
│        GitHub Repository: mohammedpalash1990-a11y/-PALASH-AI              │
│   • Branches (main / feature branches)   • Pull Requests   • Commits      │
└───────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **GitHub Connection State** (server-side in-memory, never persisted to disk): Tracks auth mode (`env_pat`, `oauth`, `session_pat`, or `none`), authenticated GitHub login handle, granted scopes, and masked verification status.
  - **Workspace Diff Snapshot**: Computed list of trackable workspace files (excluding `.data`, `node_modules`, `dist`, `.playwright-cli`, and `.env` secrets) compared against the target branch tree on `mohammedpalash1990-a11y/-PALASH-AI`.
  - **Push & PR Approval Records**: Extended approval payload metadata storing target `owner`, `repo`, `branch`, `commitMessage`, and execution result (`commitSha`, `commitUrl`, `prUrl`) so approving an item in **Approvals & Safety** executes the actual GitHub push and records the live GitHub URL in the audit log.

- **Interactive Component & State Mapping**:
  - **Connect GitHub Control**: Clicking *Connect via OAuth* requests the server-built GitHub OAuth URL and opens a popup listening for a verified `postMessage` completion event; submitting a session PAT validates it against `api.github.com/user` and stores it only in server memory for the authenticated Owner.
  - **Scan & Compare Changes Button**: Calls the backend diff endpoint to list modified/new workspace files relative to `mohammedpalash1990-a11y/-PALASH-AI`, allowing checkboxes to select/deselect files before committing.
  - **Commit & Push Action**: Validates branch name and commit message; if pushing to `main`, creates a pending approval gate and navigates/notifies the Owner; if pushing to a feature branch (with optional auto-PR toggle), executes the commit & push immediately and displays the live commit SHA and PR link.
  - **Approval Decision Handler**: When an Owner clicks *Approve* on a queued GitHub Push or PR request, the backend invokes the GitHub Push Engine, updates task progress to `100%`, and records the commit/PR URL in audit logs.

- **Security Safeguards**:
  - Credentials (`GITHUB_TOKEN`, `GITHUB_CLIENT_SECRET`, and session/OAuth tokens) remain strictly on the server and are never exposed to browser storage or API responses.
  - All outbound requests validate `api.github.com` exclusively, and workspace file collection uses canonical path confinement while blocking `.env`, `.data`, and binary build folders from ever being uploaded.
  - Every write operation (pushing commits, creating branches, opening PRs, and setting session credentials) enforces authenticated Owner verification and writes an immutable entry to the PALASH AI audit log.
